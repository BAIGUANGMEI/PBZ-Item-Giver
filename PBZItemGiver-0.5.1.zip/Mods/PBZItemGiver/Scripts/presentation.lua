-- Local typography adapter. Reuses ModMenu's label builder and UObject methods;
-- no game lookups, inventory calls or changes to the shared framework bundle.
local M = {}
local installed = setmetatable({}, {__mode = "k"})
local function copy(source)
    local result = {}
    for key, value in pairs(source) do result[key] = value end
    return result
end

function M.Install(label)
    if installed[label] then return end
    installed[label] = true
    local build = assert(label.build)
    label.build = function(ctx)
        local item = ctx.item
        if not item.fontSize and not item.color and not item.gap then return build(ctx) end
        local styled = copy(ctx)
        styled.config, styled.umg = copy(ctx.config), copy(ctx.umg)
        styled.config.fontHint = item.fontSize or ctx.config.fontHint
        styled.umg.StyleText = function(widget, size, color)
            return ctx.umg.StyleText(widget, size, item.color or color)
        end
        styled.umg.AddItemPad = function(context, name, height)
            return ctx.umg.AddItemPad(context, name, item.gap or height)
        end
        return build(styled)
    end
end

local function color(r, g, b, a) return {R = r, G = g, B = b, A = a or 1} end
M.Ink = color(0.91, 0.94, 0.97)
M.Muted = color(0.54, 0.62, 0.70)
M.Accent = color(0.38, 0.83, 0.75)
M.Warning = color(0.86, 0.68, 0.47)
M.Colors = {
    panelBg = color(0.035, 0.047, 0.062, 0.98), panelBorder = color(0.15, 0.20, 0.24),
    textPrimary = M.Ink, textMuted = M.Muted, textAccent = M.Accent, textStatus = M.Muted,
    sectionHeaderBg = color(0.06, 0.08, 0.10), sectionMark = M.Muted,
    fieldBg = color(0.075, 0.10, 0.125), fieldText = M.Ink, fieldHint = M.Muted,
    dropdownHeaderBg = color(0.075, 0.10, 0.125), dropdownHeaderText = M.Ink,
    dropdownOptionBg = color(0.045, 0.06, 0.08), dropdownOptionText = M.Ink, dropdownMore = M.Muted,
    buttonBg = color(0.10, 0.135, 0.17), buttonText = M.Ink,
    buttonBgPrimary = color(0.13, 0.53, 0.46), buttonTextPrimary = color(0.96, 1, 0.99),
    buttonBgSecondary = color(0.11, 0.15, 0.19), buttonTextSecondary = M.Ink,
    buttonBgDanger = color(0.30, 0.12, 0.15), buttonTextDanger = color(0.98, 0.68, 0.70),
    buttonBgWarning = color(0.27, 0.20, 0.11), buttonTextWarning = M.Warning,
    buttonBgDisabled = color(0.07, 0.09, 0.11), buttonTextDisabled = color(0.32, 0.38, 0.44),
    buttonBgActive = color(0.12, 0.30, 0.27), buttonTextActive = M.Accent,
    overlayDim = color(0.01, 0.02, 0.03, 0.76), confirmCardBg = color(0.06, 0.08, 0.105, 1),
    confirmDivider = color(0.16, 0.21, 0.26),
}
return M
