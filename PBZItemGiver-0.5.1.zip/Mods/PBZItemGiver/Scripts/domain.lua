-- Pure catalog rules; no calls to the running game.
local M = {}
M.Categories = {"全部", "武器", "杀气兵器", "饰品", "药品", "武器材料", "饰品材料", "药品材料",
    "其他材料", "消耗品", "珍宝", "属性道具", "饰品碎片", "任务物品", "记忆之花", "书籍与书页", "其他道具"}
M.Structs = {PBZItemDataStruct = "prop", WeaponData = "weapon", ShaqiWeaponData = "shaweapon",
    AccessoryData = "accessory", PBZMedicineDataStruct = "medicine"}

function M.Category(kind, id, detail, level, itemType, tagged)
    if kind == "weapon" then return "武器" end
    if kind == "shaweapon" then return "杀气兵器" end
    if kind == "accessory" then return "饰品" end
    if kind == "medicine" then return "药品" end
    if itemType == 4 or itemType == 5 then return "记忆之花" end
    if itemType == 1 or itemType == 2 or itemType == 3 then return "书籍与书页" end
    if detail == 2 or level == 4 or tagged then return "任务物品" end
    if detail == 1 then
        if id:match("^Weapon_Material_") then return "武器材料" end
        if id:match("^Ac_Material_") then return "饰品材料" end
        if id:match("^Medi_Material_") then return "药品材料" end
        return "其他材料"
    end
    return ({[3] = "消耗品", [4] = "珍宝", [5] = "属性道具", [6] = "饰品碎片"})[detail] or "其他道具"
end

function M.Quantity(value, kind)
    assert(type(value) == "number" and value == value and value >= 1 and value <= 99 and value % 1 == 0,
        "数量必须是 1–99 的整数")
    assert(kind == "prop" or value == 1, "武器、杀气兵器、饰品和药品每次只能获取 1 件")
    return value
end

function M.IsSingle(entry)
    if entry.kind ~= "prop" then return true end
    return entry.story == true or entry.category == "任务物品" or entry.category == "记忆之花"
        or entry.category == "书籍与书页" or entry.category == "属性道具"
end

function M.Filter(entries, category, query)
    local results = {}
    query = (query or ""):lower():match("^%s*(.-)%s*$")
    for _, entry in ipairs(entries) do
        if (not category or category == "全部" or entry.category == category)
            and (query == "" or (entry.name .. " " .. entry.id .. " " .. (entry.searchName or "")):lower():find(query, 1, true)) then
            results[#results + 1] = entry
        end
    end
    return results
end

function M.OptionLabel(entry)
    -- IDs are shown in the details; don't duplicate them on every named row.
    return entry.name
end

function M.Csv(value)
    return '"' .. tostring(value or ""):gsub('"', '""'):gsub("[\r\n]", " ") .. '"'
end

-- Data-only CSV reader. Never executes cache contents as Lua.
function M.ReadCsv(text)
    assert(type(text) == "string" and #text <= 10 * 1024 * 1024, "目录缓存过大或无效")
    text = text:gsub("^\239\187\191", "")
    local rows, row, cell = {}, {}, {}
    local quoted, closed = false, false
    local function endCell()
        row[#row + 1] = table.concat(cell); cell = {}; closed = false
    end
    local function endRow()
        endCell()
        if #row > 1 or row[1] ~= "" then rows[#rows + 1] = row end
        assert(#rows <= 20000, "目录缓存条目过多")
        row = {}
    end
    local i = 1
    while i <= #text do
        local char = text:sub(i, i)
        if quoted then
            if char == '"' then
                if text:sub(i + 1, i + 1) == '"' then cell[#cell + 1] = '"'; i = i + 1
                else quoted = false; closed = true end
            else cell[#cell + 1] = char end
        elseif char == '"' then
            assert(#cell == 0 and not closed, "目录缓存引号格式错误")
            quoted = true
        elseif char == ',' then endCell()
        elseif char == '\n' then endRow()
        elseif char ~= '\r' then
            assert(not closed, "目录缓存字段格式错误")
            cell[#cell + 1] = char
        end
        i = i + 1
    end
    assert(not quoted, "目录缓存引号未闭合")
    if #cell > 0 or #row > 0 or closed then endRow() end
    assert(#rows >= 2, "目录缓存没有有效物品")
    local headers = table.remove(rows, 1)
    local columns = {}
    for i, header in ipairs(headers) do
        assert(not columns[header], "目录缓存表头重复")
        columns[header] = i
    end
    for _, key in ipairs({"kind", "id", "name", "category", "source", "resolved"}) do
        assert(columns[key], "目录缓存缺少列：" .. key)
    end
    local result = {}
    for _, values in ipairs(rows) do
        assert(#values == #headers, "目录缓存列数不一致")
        local entry = {}
        for key, index in pairs(columns) do entry[key] = values[index] end
        result[#result + 1] = entry
    end
    return result
end
return M
