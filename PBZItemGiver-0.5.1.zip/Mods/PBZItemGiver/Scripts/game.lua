local Helpers = require("UEHelpers")
local Domain = require("domain")
local Text = require("text")
local M = {Entries = {}, ByKey = {}, Tables = {}, LastGrant = 0, SingleAttempts = {}}

local function valid(obj)
    if obj == nil then return false end
    local ok, value = pcall(function() return obj:IsValid() end)
    return ok and value == true
end
local function unwrap(value)
    local ok, result = pcall(function() return value:get() end)
    return ok and result or value
end
local function field(row, key, fallback)
    local ok, value = pcall(function() return row[key] end)
    if ok and value ~= nil then return value end
    return fallback
end
local function str(value)
    if type(value) == "string" then return value end
    if value == nil then return "" end
    local ok, result = pcall(function() return value:ToString() end)
    return ok and result or ""
end
M.Valid, M.Unwrap = valid, unwrap

function M.Context()
    local pc = Helpers.GetPlayerController()
    assert(valid(pc) and valid(pc.Pawn), "请先加载存档并进入可操作场景")
    local subsystems = StaticFindObject("/Script/Engine.Default__SubsystemBlueprintLibrary")
    local bagClass = StaticFindObject("/Script/ProjectPBZ.PBZBackPackSubsystem")
    assert(valid(subsystems) and valid(bagClass), "未找到游戏背包接口")
    local bag = subsystems:GetWorldSubsystem(pc, bagClass)
    assert(valid(bag), "背包尚未就绪")
    local eventsClass = StaticFindObject("/Script/ProjectPBZ.EventPipelineManager")
    local events = valid(eventsClass) and subsystems:GetWorldSubsystem(pc, eventsClass) or nil
    return bag, pc, events
end

function M.ResolveText(loc, events)
    return Text.New(events).Resolve(loc)
end

local specs = {
    prop = {name = "ItemName", desc = "ItemDescription", getter = "GetPropData"},
    weapon = {name = "WeaponName", desc = "EquipDescription", getter = "GetMainWeaponTableData"},
    shaweapon = {name = "WeaponName", desc = "EquipDescription", getter = "GetShaqiWeaponTableData"},
    accessory = {name = "AccessoryName", desc = "AccessoryDesc", getter = "GetAccessoryData"},
    medicine = {name = "Name", desc = "Desc", getter = "GetMedicineData"},
}

local function entryFrom(kind, row, rowName, source, resolver)
    local id = str(field(row, "ItemId"))
    if id == "" or id == "None" then id = str(rowName) end
    if id == "" or id == "None" then return nil end
    local spec = specs[kind]
    local loc = field(row, spec.name)
    local name, nameSource = resolver.Resolve(loc)
    local tag = str(field(field(row, "AddTagWhenHas"), "TagName"))
    local tagged = tag ~= "" and tag ~= "None"
    local detail, level, itemType = field(row, "ItemDetailType", 0), field(row, "ItemLevel", 0), field(row, "ItemType", 0)
    return {
        key = kind .. ":" .. id, id = id, kind = kind,
        name = name, resolved = name ~= "", nameSource = nameSource,
        nameRank = name == "" and 0 or (Text.HasChinese(name) and 4 or 3),
        searchName = Text.Internal(id) .. " " .. str(field(loc, "Key")),
        rawKey = str(field(loc, "Key")),
        description = resolver.Resolve(field(row, spec.desc)), source = source,
        relatedId = str(field(row, "IntegrationItemID")), itemType = itemType,
        category = Domain.Category(kind, id, detail, level, itemType, tagged),
        story = tagged or level == 4 or detail == 2 or itemType == 4 or itemType == 5,
    }
end

-- Books/pages and memory flowers frequently have no standalone ItemName in game data.
-- Use real book ordering/relationships when available; otherwise show an honest type/internal label.
function M.Enrich(entries, byKey, books, bag)
    local function rename(entry, value, source, rank)
        if entry and type(value) == "string" and value ~= "" and (entry.nameRank or 0) < rank then
            entry.name, entry.nameSource, entry.nameRank = value, source, rank
            entry.resolved = rank >= 2
        end
    end
    for id, book in pairs(books) do rename(byKey["prop:" .. id], book.name, "book", 4) end
    local order = field(bag, "BookPageOrderData")
    if valid(order) then
        for _, mapName in ipairs({"BookToOrderedPages", "LetterToOrderedPages"}) do
            pcall(function()
                order[mapName]:ForEach(function(key, value)
                    local bookId = str(unwrap(key))
                    local book = books[bookId]
                    local parent = byKey["prop:" .. bookId]
                    local title = book and book.name or (parent and parent.name or "")
                    if title == "" then return end
                    local ids = unwrap(value).PageIds
                    for index = 1, #ids do
                        rename(byKey["prop:" .. str(unwrap(ids[index]))],
                            string.format("《%s》· 第 %d 页", title, index), "book-page", 2)
                    end
                end)
            end)
        end
    end
    for _, entry in ipairs(entries) do
        if not entry.resolved and entry.relatedId ~= "" and entry.relatedId ~= "None" then
            local parent = byKey["prop:" .. entry.relatedId]
            local book = books[entry.relatedId]
            local title = book and book.name or (parent and parent.resolved and parent.name or "")
            if title ~= "" then
                local suffix = entry.itemType == 5 and "记忆花瓣" or (entry.itemType == 2 and "书页" or "关联物品")
                rename(entry, title .. " · " .. suffix .. " [" .. entry.id .. "]", "related", 2)
            end
        end
        if entry.name == "" then
            if entry.itemType == 4 then entry.name = "记忆之花 · " .. entry.id
            elseif entry.itemType == 5 then entry.name = "记忆花瓣 · " .. entry.id
            elseif entry.itemType == 2 then entry.name = "书页 · " .. Text.Internal(entry.id)
            else entry.name, entry.nameSource = Text.InternalLabel(entry.id, entry.rawKey) end
            if not entry.nameSource or entry.nameSource == "missing" then entry.nameSource = "internal" end
            entry.nameRank = 0
        end
    end
end

-- Opening F7 only reads this successful snapshot. No UObject lookup, conversion or scan.
function M.LoadCache(path)
    local file = assert(io.open(path, "rb"), "没有可用的目录缓存，请手动刷新目录")
    local content = file:read("a"); file:close()
    local records = Domain.ReadCsv(content)
    local entries, byKey, tables, sources = {}, {}, {}, {}
    for _, record in ipairs(records) do
        assert(specs[record.kind], "缓存含未知物品类型")
        assert(record.id ~= "" and #record.id <= 256, "缓存物品 ID 无效")
        local key = record.kind .. ":" .. record.id
        assert(not byKey[key], "缓存物品 ID 重复")
        local resolved = record.resolved == "true" and record.name ~= ""
            and not record.name:find("[名称未解析]", 1, true)
            and not record.name:match("^Weapon_%d+$")
        local name, origin = record.name, record.name_source or "cached"
        if not resolved then
            if record.category == "记忆之花" then name, origin = "记忆道具 · " .. record.id, "internal"
            elseif record.category == "书籍与书页" then name, origin = "书籍/书页 · " .. record.id, "internal"
            else name, origin = Text.InternalLabel(record.id, record.raw_key) end
        end
        local entry = {key = key, id = record.id, kind = record.kind, name = name, resolved = resolved,
            nameSource = origin, nameRank = resolved and (Text.HasChinese(name) and 4 or 3) or 0,
            searchName = Text.Internal(record.id) .. " " .. (record.raw_key or ""), rawKey = record.raw_key or "",
            category = record.category, description = record.description or "", source = record.source,
            story = record.category == "任务物品" or record.category == "记忆之花"}
        entries[#entries + 1] = entry; byKey[key] = entry
        if not sources[entry.source] then
            sources[entry.source] = true; tables[#tables + 1] = {source = entry.source}
        end
    end
    table.sort(entries, function(a, b)
        if a.nameRank ~= b.nameRank then return a.nameRank > b.nameRank end
        if a.category ~= b.category then return a.category < b.category end
        if a.name ~= b.name then return a.name < b.name end
        return a.key < b.key
    end)
    M.Entries, M.ByKey, M.Tables, M.CatalogOrigin = entries, byKey, tables, "cache"
    return entries
end

function M.Scan(exportPath)
    print("[PBZItemGiver] Manual scan: context\n")
    local bag, _, events = M.Context()
    local resolver = Text.New(events)
    local entries, byKey, tables, books = {}, {}, {}, {}
    local function add(kind, row, name, source)
        local entry = entryFrom(kind, row, name, source, resolver)
        if entry then
            local previous = byKey[entry.key]
            if not previous then entries[#entries + 1] = entry; byKey[entry.key] = entry
            elseif entry.nameRank > previous.nameRank then
                for key, value in pairs(entry) do previous[key] = value end
            end
        end
    end
    -- Only iterate already-loaded tables. Never call bulk inventory/GM functions.
    for _, dt in ipairs(FindAllOf("DataTable") or {}) do
        if valid(dt) then
            local ok, err = pcall(function()
                local rowStruct = dt:GetRowStruct()
                if not valid(rowStruct) then return end
                local rowType = rowStruct:GetFName():ToString()
                local kind = Domain.Structs[rowType]
                if rowType == "BookDataStruct" then
                    dt:ForEachRow(function(rowName, row)
                        local id = str(field(row, "ItemId"))
                        if id == "" or id == "None" then id = str(rowName) end
                        local title = resolver.Resolve(field(row, "BookName"))
                        if title ~= "" then books[id] = {name = title} end
                    end)
                    return
                end
                if not kind then return end
                local source = dt:GetFullName()
                print("[PBZItemGiver] Manual scan table: " .. source .. "\n")
                local count = 0
                dt:ForEachRow(function(rowName, row)
                    add(kind, row, rowName, source)
                    count = count + 1
                end)
                tables[#tables + 1] = {source = source, rowType = rowType, count = count}
            end)
            if not ok then print("[PBZItemGiver] Table scan: " .. tostring(err) .. "\n") end
        end
    end
    print("[PBZItemGiver] Manual scan: merge inventory\n")
    -- Fall back to actual owned props if a build does not expose DataTable iteration.
    bag.Inventories:ForEach(function(key, value)
        local info = unwrap(value)
        if valid(info) then add("prop", info.ItemDataStruct, unwrap(key), "当前背包", events) end
    end)
    assert(#entries > 0, "尚未读到道具数据，请进入场景后刷新")
    print("[PBZItemGiver] Manual scan: related names\n")
    M.Enrich(entries, byKey, books, bag)
    table.sort(entries, function(a, b)
        if a.nameRank ~= b.nameRank then return a.nameRank > b.nameRank end
        if a.category ~= b.category then return a.category < b.category end
        if a.name ~= b.name then return a.name < b.name end
        return a.key < b.key
    end)
    M.Entries, M.ByKey, M.Tables, M.CatalogOrigin = entries, byKey, tables, "live"
    if exportPath then
        local rows = {"kind,id,name,category,source,resolved,name_source,raw_key,description"}
        for _, entry in ipairs(entries) do
            rows[#rows + 1] = table.concat({Domain.Csv(entry.kind), Domain.Csv(entry.id), Domain.Csv(entry.name),
                Domain.Csv(entry.category), Domain.Csv(entry.source), tostring(entry.resolved), Domain.Csv(entry.nameSource),
                Domain.Csv(entry.rawKey), Domain.Csv(entry.description)}, ",")
        end
        local file = assert(io.open(exportPath, "wb"))
        file:write("\239\187\191" .. table.concat(rows, "\n") .. "\n"); file:close()
    end
    return entries
end

function M.Owned(entry)
    local bag = M.Context()
    local id = FName(entry.id, EFindName.FNAME_Add)
    if entry.kind == "prop" then return bag:GetUsablePropNum(id) end
    if entry.kind == "weapon" then return bag:HasWeapon(id, true) and 1 or 0 end
    if entry.kind == "shaweapon" then return bag:HasWeapon(id, false) and 1 or 0 end
    local map = entry.kind == "accessory" and bag.Accessories or bag.MedicineInfos
    return map:Contains(id) and 1 or 0
end

-- Read-only duplicate policy. Special props also retain HasMaxAmount after
-- consumption/composition/removal, so a zero usable count alone is insufficient.
function M.GrantState(entry, bag, data)
    bag = bag or M.Context()
    local single = Domain.IsSingle(entry)
    if entry.kind == "prop" then
        if not data then
            local defaults = StaticFindObject("/Script/ProjectPBZ.Default__PBZBackPackSubsystem")
            assert(valid(defaults), "未找到物品查询接口")
            data = defaults:GetPropData(FName(entry.id, EFindName.FNAME_Add))
        end
        assert(str(field(data, "ItemId")) == entry.id, "无法核实物品 ID，获取已禁用")
        local tag = str(field(field(data, "AddTagWhenHas"), "TagName"))
        local tagged = tag ~= "" and tag ~= "None"
        local category = Domain.Category("prop", entry.id, field(data, "ItemDetailType", 0),
            field(data, "ItemLevel", 0), field(data, "ItemType", 0), tagged)
        single = single or Domain.IsSingle({kind = "prop", category = category, story = tagged})
    end
    if not single then return {single = false, blocked = false} end
    local owned = M.Owned(entry)
    assert(type(owned) == "number" and owned >= 0, "无法读取持有状态，获取已禁用")
    if owned > 0 then return {single = true, blocked = true, reason = "已拥有，仅限 1 件"} end
    if entry.kind == "prop" then
        local parent = str(field(data, "IntegrationItemID"))
        local itemType = field(data, "ItemType", 0)
        local history, parentHistory = false, false
        bag.Inventories:ForEach(function(key, value)
            local id = str(unwrap(key))
            if id ~= entry.id and not (itemType == 5 and id == parent and parent ~= "None" and parent ~= "") then return end
            local info = unwrap(value)
            assert(valid(info), "历史持有记录尚未就绪，获取已禁用")
            local amount, maximum = field(info, "CurrentAmount"), field(info, "HasMaxAmount")
            assert(type(amount) == "number" and type(maximum) == "number" and amount >= 0 and maximum >= 0,
                "无法核实历史持有记录，获取已禁用")
            if amount > 0 or maximum > 0 then
                if id == entry.id then history = true else parentHistory = true end
            end
        end)
        if history or parentHistory then
            return {single = true, blocked = true, reason = parentHistory and "所属完整收集物已获取，不再重复添加" or "曾经获取过，不再重复添加"}
        end
    end
    if M.SingleAttempts[entry.key] then
        return {single = true, blocked = true, reason = "本次场景已提交获取，不再重复添加"}
    end
    return {single = true, blocked = false}
end

function M.Grant(key, quantity)
    local entry = assert(M.ByKey[key], "请先选择目录中的物品")
    quantity = Domain.Quantity(quantity, entry.kind)
    assert(os.time() - M.LastGrant >= 2, "两次获取请至少间隔 2 秒")
    local bag, pc = M.Context()
    -- Inventory screens pause the world. Mutations run on the game thread and do not
    -- request pickup popups, so a paused inventory screen is not a rejection reason.
    local defaults = StaticFindObject("/Script/ProjectPBZ.Default__PBZBackPackSubsystem")
    assert(valid(defaults), "未找到物品查询接口")
    local id = FName(entry.id, EFindName.FNAME_Add)
    local getter = specs[entry.kind].getter
    local data = defaults[getter](defaults, id)
    assert(str(field(data, "ItemId")) == entry.id, "游戏无法验证该物品 ID，未执行获取")
    local before = M.Owned(entry)
    local policy = M.GrantState(entry, bag, data)
    assert(not policy.single or quantity == 1, "装备和特殊物品只能获取 1 件")
    assert(not policy.blocked, policy.reason or "已经获取，不再重复添加")
    M.LastGrant = os.time()
    if policy.single then M.SingleAttempts[entry.key] = true end
    if entry.kind == "prop" then bag:AddPropsToBackPack(quantity, id, false)
    elseif entry.kind == "weapon" then bag:AddWeaponItem(id, true, false, false, false)
    elseif entry.kind == "shaweapon" then bag:AddWeaponItem(id, false, false, false, false)
    elseif entry.kind == "accessory" then bag:PushAccessoryToInventory(id, false)
    elseif entry.kind == "medicine" then bag:PushMedicineToInventory(id, false, false)
    else error("该物品类型尚未支持") end
    local after = M.Owned(entry)
    print(string.format("[PBZItemGiver] MANUAL_GRANT kind=%s id=%s requested=%d before=%s after=%s\n",
        entry.kind, entry.id, quantity, tostring(before), tostring(after)))
    if entry.category == "记忆之花" or entry.category == "书籍与书页" then
        return string.format("已向游戏提交：%s ×%d（库存 %s → %s）。收集物可能自动合成/去重；请重开背包查看，不要连续重复获取。",
            entry.name, quantity, tostring(before), tostring(after))
    end
    assert(type(after) == "number" and type(before) == "number" and after > before,
        "已提交但未检测到数量增加，可能达到上限；请重开背包检查，不要连续点击")
    return string.format("已获取：%s ×%d（%d → %d）；请通过游戏正常保存", entry.name, after - before, before, after)
end

function M.CanRemove(entry)
    return entry ~= nil and (entry.kind == "prop" or entry.kind == "weapon" or entry.kind == "shaweapon")
end

function M.IsFlower(entry)
    return entry ~= nil and entry.kind == "prop" and entry.category == "记忆之花"
end

-- Static analysis of this build confirms that current flower completion counts
-- petal CurrentAmount > 0, and the owned list includes complete flowers OR petals.
-- The plan reads the game's actual relationship table, never guesses by ID prefix.
function M.PlanFlowerRemoval(key)
    local entry = assert(M.ByKey[key], "请选择记忆之花或花瓣")
    assert(M.IsFlower(entry), "同步取消仅支持记忆之花与花瓣")
    local bag = M.Context()
    local defaults = StaticFindObject("/Script/ProjectPBZ.Default__PBZBackPackSubsystem")
    assert(valid(defaults), "未找到物品查询接口")
    local function data(id)
        local row = defaults:GetPropData(FName(id, EFindName.FNAME_Add))
        assert(str(field(row, "ItemId")) == id, "关联物品 ID 无法验证，未执行删除")
        return row
    end
    local selectedRow = data(entry.id)
    local itemType = field(selectedRow, "ItemType")
    assert(itemType == 4 or itemType == 5, "游戏未将该物品识别为记忆之花或花瓣")
    local rootId = itemType == 4 and entry.id or str(field(selectedRow, "IntegrationItemID"))
    assert(rootId ~= "" and rootId ~= "None", "未找到花瓣所属花朵，未执行删除")
    assert(field(data(rootId), "ItemType") == 4, "关联完整花朵类型无效")
    local order = field(bag, "BookPageOrderData")
    assert(valid(order), "游戏花瓣关系表尚未就绪，未执行删除")
    local petals, found, seen = {}, false, {}
    order.MemoryFlowerToOrderedPetals:ForEach(function(mapKey, value)
        if str(unwrap(mapKey)) ~= rootId then return end
        assert(not found, "花瓣关系表存在重复记录")
        found = true
        local ids = unwrap(value).PageIds
        assert(#ids > 0 and #ids <= 64, "花瓣数量无效，未执行删除")
        for index = 1, #ids do
            local id = str(unwrap(ids[index]))
            assert(id ~= "" and id ~= "None" and id ~= rootId and not seen[id], "花瓣关系存在无效或重复 ID")
            local row = data(id)
            assert(field(row, "ItemType") == 5 and str(field(row, "IntegrationItemID")) == rootId,
                "花瓣所属关系不一致，未执行删除")
            seen[id] = true; petals[#petals + 1] = id
        end
    end)
    assert(found and (itemType == 4 or seen[entry.id]), "未找到完整且匹配的花瓣关系，未执行删除")
    table.sort(petals)
    petals[#petals + 1] = rootId -- remove the complete flower last
    local targets, signature, total = {}, {}, 0
    for _, id in ipairs(petals) do
        local amount = bag:GetUsablePropNum(FName(id, EFindName.FNAME_Add))
        assert(type(amount) == "number" and amount >= 0 and amount <= 2147483647 and amount % 1 == 0,
            "关联物品数量无效，未执行删除")
        local cached = M.ByKey["prop:" .. id]
        targets[#targets + 1] = {id = id, name = cached and cached.name or id, amount = amount}
        signature[#signature + 1] = id .. "=" .. tostring(amount)
        total = total + amount
    end
    return {key = key, rootId = rootId, targets = targets, signature = table.concat(signature, "|"), total = total}
end

function M.RemoveFlowerCollection(plan)
    assert(type(plan) == "table", "同步删除计划无效")
    assert(os.time() - M.LastGrant >= 2, "两次操作请至少间隔 2 秒")
    local current = M.PlanFlowerRemoval(plan.key)
    assert(current.rootId == plan.rootId and current.signature == plan.signature,
        "花瓣关系或持有数量已变化，请重新确认；未执行同步删除")
    assert(current.total > 0, "该朵花及关联花瓣均未持有，无需同步删除")
    local bag = M.Context()
    M.LastGrant = os.time()
    local removed = 0
    print("[PBZItemGiver] MANUAL_FLOWER_RESET_BEGIN root=" .. current.rootId .. " " .. current.signature .. "\n")
    local ok, err = pcall(function()
        for _, target in ipairs(current.targets) do
            if target.amount > 0 then
                local id = FName(target.id, EFindName.FNAME_Add)
                assert(bag:GetUsablePropNum(id) == target.amount, "执行中数量变化，已停止")
                bag:RemovePropsFromBackPack(target.amount, id, true)
                print(string.format("[PBZItemGiver] MANUAL_FLOWER_REMOVE id=%s before=%d after=%s\n",
                    target.id, target.amount, tostring(bag:GetUsablePropNum(id))))
                assert(bag:GetUsablePropNum(id) == 0, "删除后数量不为零，已停止")
                removed = removed + 1
            end
        end
        -- Delegates may run while deleting. Verify the WHOLE family after all calls.
        local after = M.PlanFlowerRemoval(plan.key)
        assert(after.rootId == current.rootId, "花瓣关系变化")
        assert(#after.targets == #current.targets, "花瓣关系变化")
        for index, target in ipairs(after.targets) do
            assert(target.id == current.targets[index].id and target.amount == 0, "关联条目未完全清零")
        end
    end)
    if not ok then
        error(string.format("同步删除未全部完成（已确认清零 %d 项）：%s。可能已部分修改，请检查日志；未自动回滚或保存。", removed, tostring(err)))
    end
    print("[PBZItemGiver] MANUAL_FLOWER_RESET_END root=" .. current.rootId .. " cleared=" .. removed .. "\n")
    return string.format("已清零这朵花及关联花瓣（%d 项）。请重开收集界面验证当前收集；历史、世界拾取与任务进度未重置。", removed)
end

-- Only genuine inventory removal APIs. Never negative grants, UseProps (consumption
-- effects), direct TMap edits, or reset/clear inventory functions.
function M.Remove(key, quantity, removeAll, expected)
    local entry = assert(M.ByKey[key], "请先选择目录中的物品")
    assert(M.CanRemove(entry), "此类型尚未找到明确的库存删除接口，暂不支持移除")
    assert(type(removeAll) == "boolean", "移除方式无效")
    if not removeAll then quantity = Domain.Quantity(quantity, entry.kind) end
    assert(os.time() - M.LastGrant >= 2, "两次操作请至少间隔 2 秒")
    local bag = M.Context()
    local id = FName(entry.id, EFindName.FNAME_Add)
    local before = M.Owned(entry)
    assert(type(before) == "number" and before > 0 and before % 1 == 0, "没有持有该物品")
    assert(before == expected, "持有数量已变化，请重新选择并确认")
    quantity = removeAll and before or quantity
    assert(quantity <= before, "减少数量超过持有数量，未执行操作")
    if entry.kind ~= "prop" then
        assert(bag:IsEquipWeaponsByID(entry.kind == "weapon", id) == false, "请先在游戏中卸下该武器，再移除")
    end
    M.LastGrant = os.time()
    if entry.kind == "prop" then bag:RemovePropsFromBackPack(quantity, id, true)
    else bag:RemoveWeaponByID(id, entry.kind == "weapon") end
    local after = M.Owned(entry)
    print(string.format("[PBZItemGiver] MANUAL_REMOVE kind=%s id=%s requested=%d before=%s after=%s\n",
        entry.kind, entry.id, quantity, tostring(before), tostring(after)))
    assert(type(after) == "number" and after == before - quantity,
        "已提交移除但数量与预期不符，请重开背包检查，不要重复点击")
    return string.format("已移除：%s ×%d（%d → %d）；请通过游戏正常保存", entry.name, quantity, before, after)
end
return M
