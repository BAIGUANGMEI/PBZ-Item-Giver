-- Read-only localization fallbacks. Never changes the game's culture/language.
local M = {}
function M.Field(value, key, fallback)
    local ok, result = pcall(function() return value[key] end)
    return ok and result ~= nil and result or fallback
end
function M.String(value)
    if type(value) == "string" then return value end
    if value == nil then return "" end
    local ok, result = pcall(function() return value:ToString() end)
    return ok and type(result) == "string" and result or ""
end
function M.Clean(value)
    return M.String(value):gsub("<[^>]*>", ""):gsub("\r", ""):match("^%s*(.-)%s*$")
end
function M.HasChinese(value)
    local ok, result = pcall(function()
        for _, cp in utf8.codes(value) do
            if cp >= 0x3400 and cp <= 0x9fff then return true end
        end
        return false
    end)
    return ok and result or false
end
function M.Short(value, limit)
    limit = limit or 180
    local ok, offset = pcall(utf8.offset, value, limit + 1)
    if ok and offset then return value:sub(1, offset - 1) .. "…" end
    return value
end
function M.Internal(id)
    return id:gsub("^AC_", ""):gsub("_", " "):gsub("(%l)(%u)", "%1 %2")
        :gsub("(%u)(%u%l)", "%1 %2"):gsub("%s+", " ")
end
function M.InternalLabel(id, key)
    key = M.Clean(key)
    -- Prefer a meaningful English/raw text key over an opaque numeric ID.
    if key ~= "" and #key <= 100 and key:find("%a") and not (#key >= 24 and key:match("^%x+$"))
        and not key:match("^[%a_]+_%d+$")
        and not ({ItemName = true, WeaponName = true, AccessoryName = true, Name = true})[key] then
        return M.Internal(key), "internal-key"
    end
    return M.Internal(id), "internal"
end

local function call(object, method, ...)
    local args = table.pack(...)
    return pcall(function() return object[method](object, table.unpack(args, 1, args.n)) end)
end

function M.New(events)
    -- Deliberately limited to the two calls already used successfully in 0.2.
    -- pcall cannot catch a C++ access violation: do not pass hand-built FLocText,
    -- FText out parameters, or call Kismet/ELT source-string APIs here.
    local cache = {}
    return {Resolve = function(loc)
        if loc == nil then return "", "missing" end
        local namespace, key = M.String(M.Field(loc, "Namespace")), M.String(M.Field(loc, "Key"))
        local cacheKey = namespace .. "\0" .. key
        if key ~= "" and cache[cacheKey] then return table.unpack(cache[cacheKey]) end
        local best, bestSource, bestRank = "", "missing", -1
        local function add(value, source, rank)
            value = M.Clean(value)
            if value == "" or value == "None" then return end
            -- A returned localization token is not a translated item name.
            if value == key and not M.HasChinese(value) and value:find("[_/%.]") then return end
            rank = rank + (M.HasChinese(value) and 100 or 0)
            if rank > bestRank then best, bestSource, bestRank = value, source, rank end
        end
        if type(loc) == "string" then add(loc, "native", 30) end
        for _, method in ipairs({"Conv_LocTextToString", "Conv_LocTextToText"}) do
            local ok, result = call(events, method, loc)
            if ok then
                add(result, "localized", 50)
            end
        end
        local cached = M.Field(loc, "ValueCache")
        add(cached, "cached", 40)
        if key ~= "" then cache[cacheKey] = {best, bestSource} end
        return best, bestSource
    end}
end
return M
