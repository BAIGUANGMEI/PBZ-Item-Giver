-- No automatic granting. F7 opens the in-game Chinese item browser.
local Game = require("game")
local Domain = require("domain")
local Text = require("text")
local Menu = require("ModMenu.ModMenu")
local UI = require("presentation")
UI.Install(require("ModMenu.widgets.label"))
local scriptPath = assert(debug.getinfo(1, "S").source:sub(2):match("^(.*[/\\])"))
local selected, category, query = nil, "全部", ""
local busy, scanned = false, false
local nameSources = {localized = "游戏文本", native = "原始文本", cached = "游戏缓存", source = "源语言文本",
    ["zh-table"] = "中文文本表", ["en-table"] = "英文文本表", book = "书籍名称", ["book-page"] = "书名与页码",
    related = "关联物品名称", internal = "内部名称（非正式物品名）", ["internal-key"] = "原始文本键（非正式物品名）", missing = "内部名称"}

local function status(message)
    Menu.SetLabel("Browser", "status", message)
    print("[PBZItemGiver] " .. tostring(message) .. "\n")
end
local function onGameThread(action)
    ExecuteInGameThread(function()
        local ok, err = pcall(action)
        if not ok then busy = false; status("未完成：" .. tostring(err)) end
    end)
end
local function describe()
    local entry = selected and Game.ByKey[selected] or nil
    Menu.SetButtonEnabled("Browser", "grant", entry ~= nil)
    Menu.SetButtonEnabled("Browser", "reduce", Game.CanRemove(entry))
    Menu.SetButtonEnabled("Browser", "remove", Game.CanRemove(entry))
    if not entry then
        Menu.SetLabel("Browser", "detail", "尚未选择物品")
        Menu.SetLabel("Browser", "summary", "从上方列表选择，查看持有数量与说明")
        Menu.SetLabel("Browser", "identity", "")
        Menu.SetLabel("Browser", "preview", "")
        Menu.SetLabel("Browser", "notice", "")
        Menu.SetLabel("Browser", "description", "")
        Menu.SetLabel("Browser", "metadata", "")
        return
    end
    local ok, owned = pcall(Game.Owned, entry)
    local note = entry.story and "收集 / 任务进度不会随库存删除而回退。" or ""
    if Game.IsFlower(entry) then note = "单项删除可能仍显示已收集；可在“移除物品”中勾选同步取消当前收集。" end
    if not Game.CanRemove(entry) then note = note .. (note ~= "" and "\n" or "") .. "此类型目前仅支持获取。" end
    local policyOK, policy = pcall(Game.GrantState, entry)
    local single = Domain.IsSingle(entry) or (policyOK and policy.single)
    local countHint = single and " · 限 1 件" or ""
    if single and Menu.Get("Browser", "quantity") ~= 1 then Menu.Set("Browser", "quantity", 1) end
    Menu.SetButtonEnabled("Browser", "grant", policyOK and not policy.blocked)
    if not policyOK then note = note .. "\n无法核实获取状态，暂不能获取。"
    elseif policy.blocked then note = note .. "\n" .. policy.reason end
    Menu.SetLabel("Browser", "detail", entry.name)
    Menu.SetLabel("Browser", "summary", string.format("%s    /    持有 %s%s", entry.category, ok and tostring(owned) or "—", countHint))
    Menu.SetLabel("Browser", "identity", "ID  " .. entry.id)
    Menu.SetLabel("Browser", "preview", Text.Short(entry.description, 85))
    Menu.SetLabel("Browser", "notice", note)
    Menu.SetButtonEnabled("Browser", "reduce", Game.CanRemove(entry) and ok and owned > 0)
    Menu.SetButtonEnabled("Browser", "remove", Game.CanRemove(entry) and
        ((ok and owned > 0) or (Game.IsFlower(entry) and Menu.Get("Browser", "syncFlower") == true)))
    Menu.SetLabel("Browser", "description", entry.description ~= "" and entry.description or "游戏未提供独立说明。")
    Menu.SetLabel("Browser", "metadata", string.format("ID：%s\n名称来源：%s\n数据：%s", entry.id,
        nameSources[entry.nameSource] or entry.nameSource or "游戏文本", entry.source))
end
local function filter()
    local options = {}
    local keepSelection = false
    for _, entry in ipairs(Domain.Filter(Game.Entries, category, query)) do
        options[#options + 1] = {label = Domain.OptionLabel(entry), value = entry.key}
        if entry.key == selected then keepSelection = true end
    end
    local resultCount = #options
    if resultCount == 0 then options = {{label = "没有匹配的物品", value = "__empty"}} end
    if not keepSelection then selected = nil end
    Menu.SetOptions("Browser", "item", options, selected or false)
    Menu.SetLabel("Browser", "results", string.format("当前筛选：%d 项  ·  目录 %d 项", resultCount, #Game.Entries))
    describe()
end
local function refreshViews()
        local counts = {["全部"] = #Game.Entries}
        for _, entry in ipairs(Game.Entries) do counts[entry.category] = (counts[entry.category] or 0) + 1 end
        local categories = {}
        for _, label in ipairs(Domain.Categories) do
            categories[#categories + 1] = {label = string.format("%s  (%d)", label, counts[label] or 0), value = label}
        end
        Menu.SetOptions("Browser", "category", categories, category)
        filter()
        local resolved = 0
        for _, entry in ipairs(Game.Entries) do if entry.resolved then resolved = resolved + 1 end end
        if Game.CatalogOrigin == "cache" then
            status(string.format("目录就绪  ·  %d 项  /  %d 项有名称", #Game.Entries, resolved))
        else
            status(string.format("%d 张道具表 · %d 项 · 文本或关联名称 %d 项，其余显示内部名称。",
                #Game.Tables, #Game.Entries, resolved))
        end
end
local function reload()
    if busy then return end
    busy = true
    onGameThread(function()
        Game.LoadCache(scriptPath .. "../catalog.csv")
        scanned, busy = true, false
        refreshViews()
        status("列表已更新  ·  所选数量已同步")
    end)
end

local function operate(mode)
    if busy then return end
    local key, quantity = selected, Menu.Get("Browser", "quantity")
    local entry = key and Game.ByKey[key]
    if not entry then return end
    onGameThread(function()
        if mode == "remove" and Game.IsFlower(entry) and Menu.Get("Browser", "syncFlower") == true then
            local plan = Game.PlanFlowerRemoval(key)
            assert(plan.total > 0, "该朵花及关联花瓣均未持有，无需同步删除")
            local lines = {"范围：本朵完整记忆之花 + 全部关联花瓣", "花朵 ID：" .. plan.rootId, ""}
            for _, target in ipairs(plan.targets) do
                lines[#lines + 1] = string.format("%s [%s]：%d → 0", target.name, target.id, target.amount)
            end
            lines[#lines + 1] = "\n仅取消当前持有/花瓣完成状态，不重置历史获得、世界拾取点、任务或已消耗效果。"
            busy = true
            Menu.Confirm({title = "同步取消当前收集", message = table.concat(lines, "\n"),
                confirmLabel = "删除本朵及全部花瓣", cancelLabel = "取消", variant = "danger",
                onCancel = function() busy = false end,
                onConfirm = function()
                    onGameThread(function()
                        local message = Game.RemoveFlowerCollection(plan)
                        busy = false; status(message); describe()
                    end)
                end})
            return
        end
        if mode ~= "grant" then
            local before = Game.Owned(entry)
            if not Game.CanRemove(entry) or before <= 0 then describe(); return end
            if mode == "reduce" then Domain.Quantity(quantity, entry.kind) end
            local amount = mode == "remove" and before or quantity
            assert(amount <= before, "减少数量超过持有数量")
            busy = true
            Menu.Confirm({title = mode == "remove" and "移除所选物品" or "减少所选物品",
                message = string.format("%s\nID：%s\n移除 %d 个：%d → %d%s", entry.name, entry.id, amount,
                    before, before - amount, entry.story and "\n仅删除库存，不能撤销收集、合成或任务进度。" or ""),
                confirmLabel = "确认移除", cancelLabel = "取消", variant = "danger",
                onCancel = function() busy = false end,
                onConfirm = function()
                    onGameThread(function()
                        local message = Game.Remove(key, quantity, mode == "remove", before)
                        busy = false; status(message); describe()
                    end)
                end})
        else
            busy = true
            local function grant()
                onGameThread(function()
                    local message = Game.Grant(key, quantity)
                    busy = false; status(message); describe()
                end)
            end
            if entry.story or entry.category == "书籍与书页" then
                Menu.Confirm({title = "获取收集或任务物品", message = string.format("%s\nID：%s · 数量：%s\n游戏可能自动合成、去重或更新收集进度；后续删除库存不能撤销这些进度。",
                    entry.name, entry.id, tostring(quantity)), confirmLabel = "确认获取", cancelLabel = "取消",
                    onCancel = function() busy = false end, onConfirm = grant})
            else grant() end
        end
    end)
end

Menu.Init({title = "藏物阁", instanceId = "PBZItemGiver", key = Key.F7, keyHint = "F7",
    dock = "right", widthFrac = 0.40, topFrac = 0.04, bottomFrac = 0.04, rightFrac = 0.018,
    theme = "dark", colors = UI.Colors, fontTitle = 25, fontSection = 17, fontItem = 16,
    fontHint = 14, fontDropdown = 16, ignoreLook = true,
    cursorMode = "modmenu", canOpen = function()
        local ok = pcall(Game.Context)
        return ok, "请先进入存档场景"
    end})
Menu.Register({id = "Browser", title = "物品管理", items = {
    {type = "label", label = "影之刃零   /   道具目录", fontSize = 12, color = UI.Muted, gap = 16},
    {type = "textinput", id = "search", label = "搜索", placeholder = "中文、英文名称或物品 ID", default = "",
        fieldWidth = 300, labelWidth = 48, maxLength = 80, onChange = function(value) query = value; onGameThread(filter) end},
    {type = "dropdown", id = "category", label = "分类", options = Domain.Categories, default = "全部",
        onChange = function(value) category = value; onGameThread(filter) end},
    {type = "label", id = "results", label = "正在载入目录……", fontSize = 12, color = UI.Muted, gap = 10},
    {type = "dropdown", id = "item", label = "选择物品", allowEmpty = true,
        placeholder = "展开列表，选择物品",
        options = {{label = "等待进入场景后读取目录", value = "__empty"}},
        onChange = function(value) selected = value; onGameThread(describe) end},
    {type = "separator"},
    {type = "label", label = "所选物品", fontSize = 12, color = UI.Accent, gap = 8},
    {type = "label", id = "detail", label = "尚未选择物品", fontSize = 23, color = UI.Ink, gap = 8},
    {type = "label", id = "summary", label = "从上方列表选择，查看持有数量与说明", fontSize = 15, color = UI.Accent, gap = 6},
    {type = "label", id = "identity", label = "", fontSize = 12, color = UI.Muted, gap = 12},
    {type = "label", id = "preview", label = "", fontSize = 14, color = UI.Ink, gap = 10},
    {type = "label", id = "notice", label = "", fontSize = 12, color = UI.Warning, gap = 10},
    {type = "separator"},
    {type = "number", id = "quantity", label = "操作数量", default = 1, min = 1, max = 99, integer = true,
        fieldWidth = 90, labelWidth = 90, onChange = function(value)
            local entry = selected and Game.ByKey[selected]
            if not entry or value == 1 then return end
            onGameThread(function()
                local ok, policy = pcall(Game.GrantState, entry)
                if Domain.IsSingle(entry) or (ok and policy.single) then Menu.Set("Browser", "quantity", 1) end
            end)
        end},
    {type = "row", items = {
        {type = "button", id = "grant", label = "获取物品", variant = "primary", enabled = false,
            onClick = function() operate("grant") end},
        {type = "button", id = "reduce", label = "减少数量", variant = "secondary", enabled = false,
            onClick = function() operate("reduce") end},
    }},
    {type = "label", id = "status", label = "选择物品后即可操作", fontSize = 13, color = UI.Muted, gap = 12},
    {type = "fold", id = "info", label = "物品说明与来源", collapsed = true, items = {
        {type = "label", id = "description", label = ""},
        {type = "label", id = "metadata", label = ""},
    }},
    {type = "fold", id = "manage", label = "移除物品", collapsed = true, items = {
        {type = "label", label = "清空所选这一种物品的库存。执行前会显示数量确认。", fontSize = 12, color = UI.Muted},
        {type = "checkbox", id = "syncFlower", label = "同步取消当前收集（记忆之花，实验性）", default = false,
            onChange = function() onGameThread(describe) end},
        {type = "label", label = "勾选后删除同一朵花及全部关联花瓣；不重置历史、拾取点或任务。只影响“移除”，不影响“减少”。",
            fontSize = 12, color = UI.Warning},
        {type = "button", id = "remove", label = "移除所选物品", variant = "danger", enabled = false,
            onClick = function() operate("remove") end},
    }},
    {type = "button", id = "refresh", label = "更新列表与持有数量", variant = "secondary", onClick = reload},
    {type = "label", label = "F7  开关面板    ·    背包未更新时，关闭后重新打开", fontSize = 12, color = UI.Muted, gap = 4},
}})
Menu.OnOpen(function()
    if not scanned then
        onGameThread(function()
            print("[PBZItemGiver] Open: load saved catalog only\n")
            local ok, err = pcall(Game.LoadCache, scriptPath .. "../catalog.csv")
            if not ok then
                status("未找到可用目录缓存；请恢复安装目录的 catalog.csv。原因：" .. tostring(err))
                return -- Never silently fall back to native scanning on open.
            end
            scanned = true
            refreshViews()
        end)
    else onGameThread(describe) end
end)
RegisterLoadMapPreHook(function()
    scanned, selected = false, nil
    Menu.Set("Browser", "syncFlower", false)
    Game.SingleAttempts = {}
    if Menu.IsOpen() then Menu.Close() end
end)
print("[PBZItemGiver] 0.5.1 loaded. Equipment and special items are single-copy; duplicates blocked.\n")
