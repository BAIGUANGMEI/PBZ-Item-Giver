# 记忆之花当前收集判定与删除范围

分析日期：2026-11-01。依据本机已导出的 ProjectPBZ.hpp 与 PBZ.exe 静态反汇编；没有启动游戏或操作库存，没有修改存档。

## 找到的状态与接口

| 项目 | 静态证据 | 含义 |
|---|---|---|
| UPBZInventoryInfo.CurrentAmount | SDK +0x380；原生查询读取这一字段 | 当前库存 |
| UPBZInventoryInfo.HasMaxAmount | SDK +0x384；GetItemNumInfo 返回它 | 历史最大持有数，不能直接称作“已收集布尔标记” |
| BookPageOrderData.MemoryFlowerToOrderedPetals | SDK +0xC8，值的 PageIds | 完整花朵对应的全部花瓣 |
| FPBZItemDataStruct.ItemType | 4=完整花朵，5=花瓣 | 需由实际游戏行验证，不能仅信缓存分类 |
| FPBZItemDataStruct.IntegrationItemID | SDK +0x244 | 花瓣所属完整花朵 |
| IsCompletedMemoryFlower | 原生体 VA 0x146961CD0 | 从有序花瓣表枚举，数 CurrentAmount>0 的花瓣，与总数比较 |
| GetAllOwnedMemoryFlowerIDs | 原生体 VA 0x146953C80 | 纳入有库存的完整花朵，也将有库存花瓣的父花朵纳入已拥有列表 |
| RemovePropsFromBackPack | 原生体 VA 0x14696C480 | 扣 CurrentAmount，广播 RemoveProps；可选广播 UpdateProps，不写 HasMaxAmount |

函数地址仅作本机该构建的静态分析定位，不写进模组、不用于运行时跳转。脚本继续通过 UE4SS 反射接口调用。

## 判断

没有在已导出的接口中找到明确的专用 Uncollect/UndoMemoryFlower。上述两个“当前拥有/完整”查询直接依赖花朵/花瓣库存，因此删除单个条目不足以保证取消显示：父花朵或同组其他花瓣仍可能存在。当前版本实现可选的“整组库存清零”，复用明确的单道具删除接口，并不伪造一个不存在的撤销函数。

这不能证明全游戏所有收集相关界面都只使用这些字段。历史获得、世界拾取 Actor 的持久化、任务、剧情、Steam 成就与已消耗效果均未定位到通用反向接口，本版不修改这些状态，也不清 HasMaxAmount、首次获得时间或整张关系表。

## 0.5.0 操作范围

- 默认关闭，仅在移除记忆之花/花瓣时应用；“减少”继续只扣所选数量。
- 只读生成计划：验证所选条目、父花朵和每个花瓣的实际类型与 IntegrationItemID；从 MemoryFlowerToOrderedPetals 取范围，不按 ID 前缀猜测，也不枚举全背包批删。
- 展示本组每项名称、ID、数量变化；用户确认后重新生成并比对关系和数量。任何不一致在删除前拒绝。
- 删除本组有库存花瓣，最后删完整花朵；每次与最终全组都检查数量是否为零。没有强制保存，也不自动加回物品。
- 原生删除回调可能造成部分失败；检测后立即停止并提示“可能已部分修改”，日志逐项记录。不是原子事务，不承诺可自动回滚。
- 只读计划、打开面板、搜索、刷新、勾选选项和取消确认均不会删除任何物品。

原始静态证据在 research/flower-native.txt、flower-logic.txt、flower-state.txt；分析脚本 research/analyze_flowers.py 只读 PE 文件，不附加进程。静态分析依赖提取至 vendor/test-runtime，不是游戏内依赖，不随更新包分发。

26 项离线测试通过：仅确认本组清零、其他花朵不变、所选库存为零但父项存在、默认关闭/确认取消、数量变化拒绝、无效/缺失/重复关系拒绝、部分失败停止，以及原有全部回归。实际游戏中的当前收集显示与保存重载结果由用户手动验证。
